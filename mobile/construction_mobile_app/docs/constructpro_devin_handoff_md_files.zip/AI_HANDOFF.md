# AI_HANDOFF.md

## Current Status

**Status:** Audit completed. Implementation has not started yet.  
**Current phase:** Ready for Phase 1 - Shared UI Foundation Refinement.  
**Last updated:** 2026-05-11 12:16

This file is the primary handoff document for any Devin account continuing the local Flutter mobile UI/UX upgrade.

---

## Project Location

Main local project root:

```text
C:\Users\Yibeltal\smart construction
```

Main Flutter mobile app directory:

```text
C:\Users\Yibeltal\smart construction\smart-construction\construction_mobile_app
```

Only modify files inside:

```text
C:\Users\Yibeltal\smart construction\smart-construction\construction_mobile_app
```

Reference-only files/folders outside the Flutter app:

```text
C:\Users\Yibeltal\smart construction\final project documentation
C:\Users\Yibeltal\smart construction\banani-ui-export (3).zip
C:\Users\Yibeltal\smart construction\repomix-output-mobile.xml
C:\Users\Yibeltal\smart construction\repomix-output-backend.xml
C:\Users\Yibeltal\smart construction\openapi.json
```

---

## Non-Negotiable Boundary

Do **not** modify backend files.

Do not modify:

```text
backend code
backend logic
backend schemas
backend routes
backend services
backend migrations
database schemas
API contracts
ML files
prediction services
weather services
report services
```

Backend files and `openapi.json` are reference-only and may be used only to understand existing endpoints, request/response payloads, auth behavior, existing data fields, and integration rules.

---

## Mobile Scope Override

The Flutter mobile app is **database/API-driven only**.

The mobile app does **not** connect to the ML system.

Do **not** implement, expose, or add mobile UI for:

```text
ML prediction
delay risk prediction
AI insights
forecasting
risk scoring
anomaly detection
weather API integration
weather forecast screens/cards
report generation
report export
report analytics
PDF report creation
prediction dashboards
ML-based alerts
```

Allowed mobile scope:

```text
authentication
project list
project creation
project dashboard/home
tasks
daily logs
budget
team/members
contractors inside team
profile
settings
sync queue
database-backed notifications if already implemented
```

Daily Log may keep manual site condition/weather-related fields if they already exist as normal database fields, such as Fine, Good, Bad, Rainy, lost hours, and manual site condition notes. Do not connect Daily Log to any weather API.

---

## Audit Summary From Previous Devin Response

Devin completed the audit and produced these key findings:

- The Flutter mobile app has all major screens already implemented.
- Project Dashboard/Home exists and delegates to the dashboard shell.
- Budget exists but needs tab-based restructuring.
- Tasks exists and currently has Board View/Kanban behavior that should be removed from mobile.
- Daily Log Wizard exists as a 7-step wizard and must remain step-based.
- More exists and needs grouping into Project, Account, and System.
- Team exists and should receive Contractors as a tab.
- Contractor creation currently exists as a standalone project screen and should be moved/reused inside Team > Contractors.
- Shared theme and reusable widget files already exist and should be refined, not rebuilt from scratch.

---

## Current Phase

### Completed

```text
Planning audit completed.
Screen-to-file map produced.
Shared component/theme targets identified.
API dependency areas identified.
Risk areas identified.
Implementation has not started.
```

### Not Started Yet

```text
handoff docs creation inside repo
shared UI foundation refinement
screen redesigns
final QA
```

---

## Immediate Next Step

Run this next in **Dev Mode**:

```text
Create or update:
- docs\AI_HANDOFF.md
- docs\MOBILE_UI_UPGRADE_PLAN.md
- docs\LOCAL_CHANGELOG.md

Then proceed to Phase 1:
Shared UI Foundation Refinement.
```

If these files have already been copied into the Flutter repo, start with Phase 1.

---

## Exact Next Phase: Shared UI Foundation Refinement

### Read first

```text
docs\AI_HANDOFF.md
docs\MOBILE_UI_UPGRADE_PLAN.md
docs\LOCAL_CHANGELOG.md
lib\core\theme\app_colors.dart
lib\core\theme\app_gradients.dart
lib\core\theme\app_radius.dart
lib\core\theme\app_shadows.dart
lib\core\theme\app_spacing.dart
lib\core\theme\app_text_styles.dart
lib\core\theme\app_theme.dart
lib\core\theme\theme_controller.dart
lib\core\widgets\app_page.dart
lib\core\widgets\app_scaffold.dart
lib\core\widgets\app_card.dart
lib\core\widgets\app_button.dart
lib\core\widgets\app_text_field.dart
lib\core\widgets\app_dropdown_field.dart
lib\core\widgets\app_bottom_nav.dart
lib\core\widgets\app_header.dart
lib\core\widgets\app_top_bar.dart
lib\core\widgets\app_icon_button.dart
lib\core\widgets\status_badge.dart
lib\core\widgets\empty_state.dart
lib\core\widgets\section_header.dart
lib\core\widgets\stat_card.dart
lib\core\widgets\action_card.dart
```

### Improve or add reusable widgets if needed

```text
lib\core\widgets\blueprint_background.dart
lib\core\widgets\app_filter_chips.dart
lib\core\widgets\app_segmented_tabs.dart
lib\core\widgets\app_bottom_sheet.dart
lib\core\widgets\animated_page_section.dart
lib\core\widgets\metric_tile.dart
```

---

## Global Design Direction

The app should look like a premium construction SaaS mobile product.

### Light mode

Use a soft off-white architectural blueprint/floor-plan background. It must not be a plain graph-paper grid. It should include pale blue-gray guide lines, faint construction drawing marks, partial wall-outline rectangles, structural line segments, floor-plan corners, tiny drafting intersections, and sparse architectural geometry behind the UI.

Keep it very subtle: opacity around 4% to 7%, never competing with content, no bright blueprint lines, no noisy technical drawings.

### Dark mode

Use a deep navy architectural blueprint/floor-plan background. It must not be pure black. It should include low-opacity navy-blue drafting lines, faint wall outlines, sparse construction guide lines, plan-like geometry, and subtle drafting intersections.

Keep it subtle: opacity around 3% to 6%, no neon blue, no noisy texture.

### Cards

```text
Light: white elevated cards, subtle border, soft shadow
Dark: elevated dark navy cards, subtle border
Rounded corners: 16px to 22px
Compact padding using 8px spacing system
```

### Typography

```text
Inter/SF Pro style
dark navy text in light mode
white text in dark mode
muted blue-gray secondary text
clear hierarchy
Amharic/localized text must not overflow badly
```

### Colors

```text
Primary blue: main actions and active states
Green: success, active, healthy, all-clear
Amber: pending, warning, closing
Red: destructive, error, urgent only
Blue-gray: inactive and neutral
```

### Motion

```text
page fade-up
cards stagger fade-up
button press scale
input focus glow
progress bars animate from 0 to value
tabs slide active indicator
bottom sheets use dim/blur backdrop and spring slide-up
empty states fade/scale in
```

---

## Product Decisions To Preserve

```text
Home is a daily command center.
Home must not duplicate Budget, Project Progress, Metrics, View Tasks, or Team.
Budget uses Overview / Breakdown / Expenses tabs.
Tasks is list-only. Remove Board View/Kanban from mobile.
More is grouped into Project / Account / System.
Contractors are inside Team as a Contractors tab.
Team remains in More under Project.
Daily Log remains a step-by-step wizard.
Daily Log add forms should be mobile-native bottom sheets where possible.
Backend is read-only.
Mobile does not use ML/weather/reports.
```

---

## High-Risk Areas

Be careful with:

```text
role-based dashboards
currentProjectRoleProvider and currentProjectProvider
offline/local storage
sync queue
daily log draft flow
task local cache
dashboard_widgets.dart because it is large/shared
contractor creation because it currently exists as standalone direct flow
budget because API fields are limited
Amharic/localization overflow
bottom navigation role filtering
```

---

## Commands To Run After Each Phase

Run when practical:

```bash
dart format .
flutter analyze
flutter test
flutter build web
```

If a command fails, document the exact error in `docs\AI_HANDOFF.md` and `docs\LOCAL_CHANGELOG.md`.

---

## When Switching Devin Accounts

The next Devin account should **not** re-read the full repomix first.

It should read only:

```text
docs\AI_HANDOFF.md
docs\MOBILE_UI_UPGRADE_PLAN.md
docs\LOCAL_CHANGELOG.md
```

Then it should return current phase, completed phases, last files changed, remaining work, exact next files to inspect, whether it is safe to continue, and the next recommended prompt.

---

## End-Of-Session Rule

Before ending any Devin session, update:

```text
docs\AI_HANDOFF.md
docs\LOCAL_CHANGELOG.md
```

Then manually create a local backup copy of:

```text
C:\Users\Yibeltal\smart construction\smart-construction\construction_mobile_app
```

Suggested backup folder pattern:

```text
C:\Users\Yibeltal\smart construction\backups\01_after_audit_docs
C:\Users\Yibeltal\smart construction\backups\02_after_ui_foundation
C:\Users\Yibeltal\smart construction\backups\03_after_project_list
C:\Users\Yibeltal\smart construction\backups\04_after_home_dashboard
C:\Users\Yibeltal\smart construction\backups\05_after_budget_tabs
C:\Users\Yibeltal\smart construction\backups\06_after_tasks_list
C:\Users\Yibeltal\smart construction\backups\07_after_more_team_contractors
C:\Users\Yibeltal\smart construction\backups\08_after_daily_logs
C:\Users\Yibeltal\smart construction\backups\09_after_daily_log_wizard
C:\Users\Yibeltal\smart construction\backups\10_final_qa
```
