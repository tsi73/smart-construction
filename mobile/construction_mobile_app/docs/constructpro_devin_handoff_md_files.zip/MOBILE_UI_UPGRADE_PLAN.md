# MOBILE_UI_UPGRADE_PLAN.md

## Purpose

This document stores the local implementation plan for the ConstructPro Flutter mobile UI/UX upgrade.

It exists so future Devin accounts can continue from the local repo without re-reading the full repomix, backend reference, Banani image zip, and final-year documentation every time.

**Last updated:** 2026-05-11 12:16

---

## Project Directory

Main Flutter mobile app:

```text
C:\Users\Yibeltal\smart construction\smart-construction\construction_mobile_app
```

Only modify files inside this Flutter mobile directory.

Reference-only files outside mobile:

```text
C:\Users\Yibeltal\smart construction\final project documentation
C:\Users\Yibeltal\smart construction\banani-ui-export (3).zip
C:\Users\Yibeltal\smart construction\repomix-output-mobile.xml
C:\Users\Yibeltal\smart construction\repomix-output-backend.xml
C:\Users\Yibeltal\smart construction\openapi.json
```

---

## Backend Rule

Backend is read-only. Do not modify backend code, routes, models, schemas, migrations, services, database schemas, API contracts, ML files, weather services, report services, or prediction services.

Use backend/OpenAPI only to understand existing mobile integration contracts.

---

## Mobile Scope

The mobile app is database/API-driven only.

Do not add mobile features for:

```text
ML prediction
risk prediction
weather API
weather forecast
report generation
report export
PDF report creation
forecasting
AI insights
anomaly detection
```

Allowed mobile scope:

```text
authentication
project list
project creation
home/project dashboard
tasks
task creation/detail
daily logs
daily log wizard
budget
team/members
contractors inside team
profile
settings
sync queue
notifications if already database-backed
```

---

## Screen-To-File Map

### Global app / routing

```text
lib\main.dart
lib\app.dart
lib\core\routing\route_names.dart
lib\core\routing\app_router.dart
```

### Theme / design system

```text
lib\core\theme\app_colors.dart
lib\core\theme\app_gradients.dart
lib\core\theme\app_radius.dart
lib\core\theme\app_shadows.dart
lib\core\theme\app_spacing.dart
lib\core\theme\app_text_styles.dart
lib\core\theme\app_theme.dart
lib\core\theme\theme_controller.dart
```

### Shared widgets

```text
lib\core\widgets\action_card.dart
lib\core\widgets\app_bottom_nav.dart
lib\core\widgets\app_button.dart
lib\core\widgets\app_card.dart
lib\core\widgets\app_dropdown_field.dart
lib\core\widgets\app_header.dart
lib\core\widgets\app_icon_button.dart
lib\core\widgets\app_page.dart
lib\core\widgets\app_scaffold.dart
lib\core\widgets\app_text_field.dart
lib\core\widgets\app_top_bar.dart
lib\core\widgets\empty_state.dart
lib\core\widgets\error_state.dart
lib\core\widgets\gradient_card.dart
lib\core\widgets\loading_skeleton.dart
lib\core\widgets\offline_banner.dart
lib\core\widgets\responsive_content.dart
lib\core\widgets\role_badge.dart
lib\core\widgets\role_guard.dart
lib\core\widgets\section_header.dart
lib\core\widgets\stat_card.dart
lib\core\widgets\state_widgets.dart
lib\core\widgets\status_badge.dart
lib\core\widgets\sync_badge.dart
```

### Auth

```text
lib\features\auth\presentation\screens\splash_page.dart
lib\features\auth\presentation\screens\login_page.dart
lib\features\auth\presentation\screens\register_page.dart
lib\features\auth\presentation\screens\forgot_password_page.dart
lib\features\auth\presentation\screens\reset_password_page.dart
lib\features\auth\presentation\widgets\auth_card.dart
lib\features\auth\presentation\widgets\auth_responsive_layout.dart
lib\features\auth\presentation\widgets\auth_brand_panel.dart
lib\features\auth\presentation\providers\auth_provider.dart
lib\features\auth\data\datasources\auth_remote_data_source.dart
```

### Project List / Project Creation

```text
lib\features\project\presentation\screens\project_list_page.dart
lib\features\project\presentation\screens\project_creation_page.dart
lib\features\project\presentation\providers\project_provider.dart
lib\features\project\presentation\controllers\project_controller.dart
lib\features\project\data\datasources\project_remote_data_source.dart
lib\features\project\data\datasources\project_local_data_source.dart
lib\features\project\data\repositories\project_repository_impl.dart
```

### Project Dashboard / Home / More

```text
lib\features\project\presentation\screens\project_dashboard_page.dart
lib\features\project\presentation\screens\dashboard\project_dashboard_shell.dart
lib\features\project\presentation\screens\dashboard\project_manager_dashboard.dart
lib\features\project\presentation\screens\dashboard\site_engineer_dashboard.dart
lib\features\project\presentation\screens\dashboard\consultant_dashboard.dart
lib\features\project\presentation\screens\dashboard\office_engineer_dashboard.dart
lib\features\project\presentation\screens\dashboard\dashboard_widgets.dart
lib\features\project\presentation\screens\dashboard\more_view.dart
```

### Budget

```text
lib\features\budget\presentation\screens\budget_page.dart
lib\features\budget\presentation\controllers\budget_controller.dart
lib\features\budget\data\datasources\budget_remote_data_source.dart
```

### Tasks

```text
lib\features\task\presentation\screens\task_list_page.dart
lib\features\task\presentation\screens\task_creation_page.dart
lib\features\task\presentation\screens\task_detail_page.dart
lib\features\task\presentation\controllers\task_controller.dart
lib\features\task\data\datasources\task_remote_data_source.dart
lib\features\task\data\datasources\task_local_data_source.dart
lib\features\task\data\repositories\task_repository_impl.dart
lib\features\task\domain\entities\task.dart
```

### Daily Logs

```text
lib\features\daily_log\presentation\screens\daily_log_list_page.dart
lib\features\daily_log\presentation\screens\daily_log_detail_page.dart
lib\features\daily_log\presentation\screens\daily_log_wizard_page.dart
lib\features\daily_log\presentation\widgets\daily_log_ui.dart
lib\features\daily_log\presentation\controllers\daily_log_controller.dart
lib\features\daily_log\data\datasources\daily_log_remote_data_source.dart
lib\features\daily_log\data\datasources\daily_log_local_data_source.dart
lib\features\daily_log\data\repositories\daily_log_repository_impl.dart
lib\features\daily_log\domain\entities\daily_log.dart
lib\features\daily_log\domain\entities\sync_queue_item.dart
```

### Team / Contractors

```text
lib\features\team\presentation\screens\team_management_page.dart
lib\features\team\presentation\widgets\member_card.dart
lib\features\team\presentation\widgets\invitation_card.dart
lib\features\team\presentation\controllers\team_controller.dart
lib\features\team\data\datasources\team_remote_data_source.dart
lib\features\team\data\repositories\team_repository_impl.dart
lib\features\team\domain\entities\project_member.dart
lib\features\project\presentation\screens\contractor_creation_page.dart
```

### Profile / Settings / Sync Queue

```text
lib\features\settings\presentation\screens\profile_page.dart
lib\features\settings\presentation\screens\settings_page.dart
lib\features\settings\presentation\screens\sync_queue_page.dart
lib\features\settings\presentation\controllers\settings_controller.dart
```

### Notifications

```text
lib\features\notifications\presentation\screens\notifications_page.dart
lib\features\notifications\presentation\widgets\notification_tile.dart
lib\features\notifications\data\datasources\notification_remote_data_source.dart
lib\features\notifications\data\repositories\notification_repository_impl.dart
lib\features\notifications\domain\role_notification_filter.dart
lib\core\notifications\notification_service.dart
```

### API / Network / Storage

```text
lib\core\network\dio_client.dart
lib\core\network\auth_interceptor.dart
lib\core\network\token_refresh_interceptor.dart
lib\core\network\network_info.dart
lib\core\databases\api\api_consumer.dart
lib\core\databases\api\dio_consumer.dart
lib\core\databases\api\end_points.dart
lib\core\config\environment.dart
lib\core\storage\app_local_storage.dart
lib\core\storage\database_service.dart
lib\core\storage\local_storage_service.dart
lib\core\storage\secure_token_storage.dart
lib\core\storage\sync_queue_data_source.dart
lib\core\storage\sync_queue_repository.dart
```

### Localization

```text
lib\l10n\app_en.arb
lib\l10n\app_am.arb
```

---

## Implementation Order

```text
Phase 0 - Handoff docs
Phase 1 - Shared UI foundation
Phase 2 - Project List
Phase 3 - Home / Project Dashboard
Phase 4 - Budget tabs
Phase 5 - Tasks list-only
Phase 6 - More grouping
Phase 7 - Team with Members / Contractors tabs
Phase 8 - Daily Logs List
Phase 9 - Daily Log Wizard
Phase 10 - Create Task
Phase 11 - Auth
Phase 12 - Profile / Settings / Sync Queue / Notifications
Phase 13 - Project Creation
Phase 14 - Final QA
```

---

## API Dependencies By Screen

### Auth

```text
POST /api/v1/auth/register
POST /api/v1/auth/login
POST /api/v1/auth/refresh
POST /api/v1/auth/forgot-password
POST /api/v1/auth/reset-password
GET /api/v1/users/me
PUT /api/v1/users/me
```

### Projects

```text
GET /api/v1/projects
POST /api/v1/projects
GET /api/v1/projects/{project_id}
PUT /api/v1/projects/{project_id}
DELETE /api/v1/projects/{project_id}
GET /api/v1/projects/{project_id}/dashboard
```

### Team / Members

```text
GET /api/v1/projects/{project_id}/members
POST /api/v1/projects/{project_id}/members
PATCH /api/v1/projects/{project_id}/members/{user_id}
DELETE /api/v1/projects/{project_id}/members/{user_id}
POST /api/v1/projects/{project_id}/invitations
GET /api/v1/projects/{project_id}/invitations
POST /api/v1/projects/invitations/accept
```

### Contractors

```text
GET /api/v1/contractors
POST /api/v1/contractors
GET /api/v1/contractors/{contractor_id}
PUT /api/v1/contractors/{contractor_id}
DELETE /api/v1/contractors/{contractor_id}
```

### Tasks

```text
GET /api/v1/projects/{project_id}/tasks
POST /api/v1/projects/{project_id}/tasks
GET /api/v1/projects/tasks/{task_id}
PUT /api/v1/projects/tasks/{task_id}
DELETE /api/v1/projects/tasks/{task_id}
```

### Daily Logs

```text
GET /api/v1/projects/{project_id}/daily-logs
POST /api/v1/projects/{project_id}/daily-logs
GET /api/v1/daily-logs/{log_id}
PATCH /api/v1/daily-logs/{log_id}/submit
review/approve/reject endpoints if already integrated
daily log child entity endpoints if already integrated
```

### Budget

```text
GET /api/v1/projects/{project_id}/budget
GET /api/v1/projects/{project_id}/budget-items
POST /api/v1/projects/{project_id}/budget-items
```

Important budget constraint: budget item fields may be limited. Do not invent status/category fields unless already supported by current API/mobile model.

---

## Role-Based Behavior To Preserve

Preserve behavior for:

```text
Project Manager / owner
Site Engineer
Consultant
Office Engineer
Admin if present
```

Preserve:

```text
currentProjectProvider
currentProjectRoleProvider
role guards
role-based dashboard rendering
role-based More menu visibility
role-based create/update/delete permissions
```

---

## Offline / Local Storage Behavior To Preserve

Preserve:

```text
daily log drafts
task cache
project cache
sync queue
web fallback storage
offline banner
theme/language persistence
secure token storage
auth session restore
```

Do not break:

```text
DailyLogLocalDataSource
TaskLocalDataSource
ProjectLocalDataSource
SyncQueueDataSource
AppLocalStorage
SecureTokenStorage
```

---

## Screen Requirements

### Project List

Add/keep: greeting/date header, search projects, status filter chips, compact project cards, progress bar, create project action, blueprint background, light/dark support.

### Home / Dashboard

Home should include compact app bar, project name, role chip, notification icon, greeting/date, Create Daily Log CTA, Today Snapshot, Action Required, Today's Focus, Latest Updates, bottom nav.

Home should not include Budget Progress, large Project Overview, Metrics shortcut, View Tasks shortcut, Team shortcut, ML risk prediction, weather cards, or report cards.

### Budget

Tabs: Overview, Breakdown, Expenses.

Overview: Budget Summary, database-backed values only, utilization progress, healthy/watch/over-budget chip.

Breakdown: category breakdown only if API/model supports categories; otherwise graceful helper state.

Expenses: expense list, FAB only on Expenses tab, filters only if fields exist.

### Tasks

Remove Board View, Kanban, horizontal task columns, and List/Board toggle.

Keep search, filter chips, task cards, create task, and task detail navigation.

### More

Structure:

```text
Project
- Team
- Project Settings

Account
- Profile
- Settings

System
- Sync Queue
- Logout
```

Do not show Contractors as a top-level row.

### Team

Tabs: Members and Contractors.

Members: member list, invite member, pending invitations if implemented, role chips.

Contractors: contractor list, empty state, add contractor, create/update/delete only if supported.

### Daily Log Wizard

Keep step-by-step wizard. Expected steps: Basic Info, Shift, Labor, Materials, Equipment, Photos, Review if current code has it.

Use bottom sheets for Add Shift, Add Labor, Add Material, Add Equipment.

Do not add weather API or ML prediction.

---

## Visual System Requirements

### Blueprint Background

Light mode: off-white base, pale blue-gray construction linework, subtle wall outlines, floor-plan corners, drafting intersections, opacity 4% to 7%.

Dark mode: deep navy base, low-opacity navy-blue drafting lines, subtle plan geometry, opacity 3% to 6%.

### Components

```text
cards: 16-22px radius
buttons: 52-56px height
inputs: 48-56px height
touch targets: at least 44px
spacing: 8px system
typography: Inter/SF Pro-like
```

### Motion

```text
page fade-up
card stagger fade-up
button press scale
input focus glow
tab indicator slide
bottom sheet spring slide-up
empty state fade/scale
progress bar animation
```

---

## Risk Areas

Be extra careful with dashboard_widgets.dart, project_dashboard_shell.dart, role-based dashboard bodies, daily_log_wizard_page.dart, daily_log_ui.dart, daily log local draft/offline flow, budget API field limitations, task cache and filters, team role permissions, contractor standalone-to-tab migration, settings persistence, Amharic localization overflow, bottom nav active state and safe areas.

---

## Files Not To Touch

Do not modify anything outside:

```text
C:\Users\Yibeltal\smart construction\smart-construction\construction_mobile_app
```

Inside mobile, avoid changing platform/build files unless absolutely necessary:

```text
android\
ios\
macos\
linux\
windows\
web\
pubspec.yaml
pubspec.lock
```

Only touch `pubspec.yaml` if a package update is absolutely required and explain why first.

Do not edit generated files manually:

```text
*.freezed.dart
*.g.dart
.flutter-plugins
.flutter-plugins-dependencies
.dart_tool
build
```

---

## QA Checklist

After each phase:

```text
dart format .
flutter analyze
```

When practical:

```text
flutter test
flutter build web
```

Final QA must confirm backend untouched, no API contract changes, no unsupported payload fields, no mobile ML/weather/reports/export UI, Contractors moved into Team, More grouped correctly, Tasks list-only, Budget tabbed, Home command-center only, Daily Log wizard remains step-based, light/dark blueprint background works, safe areas work, touch targets are at least 44px, no visible chip scrollbars, and Amharic does not overflow badly.
